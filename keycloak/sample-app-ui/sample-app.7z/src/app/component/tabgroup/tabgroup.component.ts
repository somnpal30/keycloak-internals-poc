import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabgroup',
  templateUrl: './tabgroup.component.html',
  styleUrls: ['./tabgroup.component.css']
})
export class TabgroupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
