package com.sample.keycloak.authenticator;

public class MyAuthenticator/* extends AbstractClientAuthenticator*/ {

}
