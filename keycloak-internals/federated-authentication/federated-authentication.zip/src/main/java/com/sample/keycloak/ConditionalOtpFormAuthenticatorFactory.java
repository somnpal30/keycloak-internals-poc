package com.sample.keycloak;

import org.keycloak.authentication.authenticators.challenge.BasicAuthOTPAuthenticatorFactory;

public class ConditionalOtpFormAuthenticatorFactory /*extends BasicAuthOTPAuthenticatorFactory*/ {
}
